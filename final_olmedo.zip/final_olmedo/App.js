import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';

const App = () => {
  const [temperature, setTemperature] = useState('');
  const [scale, setScale] = useState('F');
  const [backgroundColor, setBackgroundColor] = useState('#c3b091');

  const handleTemperatureChange = (text) => {
    
      setTemperature(text);
      if (scale === 'F') {
        setBackgroundColor(text >= 32 ? '#FC6400' : '#6BA7CC');
      } else {
        setBackgroundColor(text >= 0 ? '#6BA7CC' : '#FC6400');
      }
    
  };

  const convertTemperature = () => {
    if (scale === 'F') {
      return ((parseFloat(temperature) - 32) * 5) / 9;
    } else {
      return (parseFloat(temperature) * 9) / 5 + 32;
    }
  };

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={styles.title}>TEMPERATURE</Text>
      <Text style={styles.title2}>CONVERTER</Text>
      <TextInput
        style={styles.input}
        onChangeText={handleTemperatureChange}
        value={temperature}
        keyboardType="numeric"
        placeholder="Enter temperature"
      />
      <Text style={styles.temperature}>
        {scale === 'F' ? 'Fahrenheit' : 'Celsius'}
      </Text>
      <Text style={styles.result}>
        {scale === 'F' ? 'C° :  ' : 'F° :  '}
        {convertTemperature().toFixed(2)}
      </Text>
      <Text style={styles.temperature2}>
        {scale === 'F' ? 'Celsius' : 'Fahrenheit'}
      </Text>
      <Text style={styles.scaleSwitch} onPress={() => setScale(scale === 'F' ? 'C' : 'F')}>
      
        Switch to {scale === 'F' ? 'Fahrenheit' : 'Celsius'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  title2: {
    fontSize: 15,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  temperature: {
    fontSize: 10,
    fontWeight: '5',
    marginBottom: 90,
  },
  temperature2: {
    fontSize: 10,
    fontWeight: '5',
    marginBottom: 30,
  },
  result: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  scaleSwitch: {
    fontSize: 16,
    color: 'white',
  },
});

export default App;